//#include"22L6198 List.h"
//#include<iostream>
//using namespace std;
//int main()
//{
//	int size,value;
//		sortedset<int>s;
//		cout << "Enter the size of the list:";
//		cin >> size;
//		while (size <= 0)
//		{
//			cout << "Enter the size greater than 0:";
//			cin >> size;
//		}
//		for (int i = 0; i < size; i++)
//		{
//		Condition:
//			cout << "Enter the value to insert:";
//			cin >> value;
//			if (s.check(value))
//			{
//				s.insert(value);
//				cout << "Element added to the list successfully!" << endl;
//			}
//			else
//			{
//				cout << "Element cannot be added as it is already present in the list" << endl;
//				goto Condition;
//			}
//			cout << "-------------------------------------------------------------" << endl;
//		}
//		s.print();
//		s.reverse();
//	return 0;
//}